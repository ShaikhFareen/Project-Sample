# Exaggeration in fake vs. authentic reviews for luxury and budget hotels.

You can use the developed app heading to

https://prshanthreddy-nlp-app-n1rb3w.streamlit.app

